﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proiect
{
    public partial class FormLaborator : Form
    {
        public FormLaborator()
        {
            InitializeComponent();
        }

        private void FormLaborator_Load(object sender, EventArgs e)
        {
            this.Text = "Laborator";
        }
    }
}
