﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proiect
{

    public partial class FormReceptie : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mngdn\Source\Repos\Clinica2\Database.mdf;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();

        public FormReceptie()
        {
            InitializeComponent();
        }

        private void FormReceptie_Load(object sender, EventArgs e)
        {
            this.Text = "Receptie";
            cmd.Connection = con;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.CommandText = "insert into Pacienti(nume,prenume,cnp,adresa,data_nastere,sex,telefon,inaltime,greutate,id_clinica,data_update) values ('" + textBox3.Text + "','" + textBox2.Text + "','" + textBox1.Text + "','" + textBox4.Text + "','" + dateTimePicker1.Value.Date + "','" + comboBox1.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "',1,'" + DateTime.Now + "')";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Adaugat");
            con.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
